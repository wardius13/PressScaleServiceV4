﻿CREATE LOGIN [sa]
    WITH PASSWORD = N'}xGw}asbcDzfxg ofwziwcuumsFT7_&#$!~<}|rr6ybx{!kV', DEFAULT_LANGUAGE = [us_english];

