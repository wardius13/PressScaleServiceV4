﻿CREATE TABLE [dbo].[DATA]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Date] DATETIME2 NULL, 
    [Company] TEXT NULL, 
    [Product] TEXT NULL, 
    [#Balen] INT NULL, 
    [Location] TEXT NULL, 
    [Weight] INT NULL
)
