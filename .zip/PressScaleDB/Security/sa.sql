﻿CREATE LOGIN [sa]
    WITH PASSWORD = N'Xpj.Oidr8r{boeyzou|yzW4#msFT7_&#$!~<odj3ka_+zr,$', DEFAULT_LANGUAGE = [us_english];

